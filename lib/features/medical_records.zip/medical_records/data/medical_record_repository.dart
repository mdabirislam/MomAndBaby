import 'package:hive_flutter/hive_flutter.dart';
import '../../../core/database/hive_service.dart';
import '../../../shared/models/medical_record.dart';

class MedicalRecordRepository {
  final Box<MedicalRecord> _recordBox = HiveService.getBox<MedicalRecord>(HiveService.medicalRecordBoxName);

  Future<void> addRecord(MedicalRecord record) async {
    await _recordBox.add(record);
  }

  Future<void> deleteRecord(int index) async {
    await _recordBox.deleteAt(index);
  }

  List<MedicalRecord> getAllRecords() {
    final records = _recordBox.values.toList();
    records.sort((a, b) => b.date.compareTo(a.date));
    return records;
  }
}
